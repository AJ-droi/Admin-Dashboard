import React from 'react';
import "../App.css";
import {Link} from "react-router-dom"

const Login = () => {
  const submitHandler = (e) =>{
    e.preventDefault();

    window.location= "/dash";
  }

  return (
  
    <div className="login">
        <h3>Welcome</h3>
        <p>Welcome! Please enter your details</p>

        <form className="login-form">
            <div className='login-form-control'>
                <label htmlFor="email">Email</label> <br />
                <input type="text" id="email" name="Email" placeholder="Enter your email"/>
            </div>

            <div className='login-form-control'>
                <label htmlFor="pass">Password</label> <br />
                <input type="password" id="pass" placeholder="Enter your Password" name="Password" />
            </div>

            <button type="submit" onClick={submitHandler}>Sign In</button>
        </form>
        

        <p>Don't have an account? <Link to="/signup">Sign Up</Link></p>

    </div>
  )
}

export default Login