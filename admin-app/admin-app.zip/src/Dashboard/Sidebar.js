import React, { useState } from "react";
import { Link } from "react-router-dom";
import "./Dashboard.css";
import { AiFillHome, AiOutlineTeam, AiFillProject } from "react-icons/ai";
import { RiUserFollowLine, RiLogoutBoxRFill } from "react-icons/ri";
import Team from "./Team";

const Sidebar = () => {
  // const [view, SetView] = useState(false);

  // const showTeam = () => {
  //   SetView(!view);
  //   if (view){
  //     return <Team />
  //   }else{
  //     return null
  //   }
  // }
  return (
    <div className="sidebar">
      <h3>.UNTitled</h3>
      <ul>
        <li>
          <AiFillHome id="side-icon" />{" "}
          <Link id="side-link" to="">
            Home
          </Link>
        </li>
        <li>
          <AiOutlineTeam id="side-icon" />{" "}
          <Link id="side-link" to="/team">
            Team Members
          </Link>
        </li>
        <li>
          <RiUserFollowLine id="side-icon" />{" "}
          <Link id="side-link" to="">
            Client
          </Link>
        </li>
        <li>
          <AiFillProject id="side-icon" />{" "}
          <Link id="side-link" to="">
            Product
          </Link>
        </li>
        <li>
          <RiLogoutBoxRFill id="side-icon" />{" "}
          <Link id="side-link" to="">
            LogOut
          </Link>
        </li>
      </ul>
    </div>
  );
};

export default Sidebar;
