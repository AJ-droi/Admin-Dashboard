import React from 'react';
import Sidebar from './Sidebar';
import Team from './Team';




const Dashboard = () => {
 
  return (
    <div className='container1'>
      <Sidebar />
      <Team />
  
    </div>
  )
}

export default Dashboard